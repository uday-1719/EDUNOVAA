// ==========================
// PRELOADER
// ==========================

window.addEventListener("load",function(){

    setTimeout(function(){

        document.getElementById("preloader").style.display="none";

        document.getElementById("website").style.display="block";

    },2000);

});
// ============================
// Explore Courses Button
// ============================

document.querySelector(".explore-btn").onclick = function () {
    window.location.href = "courses.html";
};

// ============================
// Watch Demo Button
// ============================

document.querySelector(".demo-btn").onclick = function () {
    alert("Demo video will be available soon!");
};

// ============================
// Navigation Active Link
// ============================

var links = document.querySelectorAll("nav ul li a");

for (var i = 0; i < links.length; i++) {

    links[i].onclick = function () {

        for (var j = 0; j < links.length; j++) {
            links[j].style.color = "#334155";
        }

        this.style.color = "#2563EB";
    };

}

// ============================
// Login Button
// ============================

document.querySelector(".login-btn").onclick = function () {
    window.location.href = "login.html";
};

// ============================
// Signup Button
// ============================

document.querySelector(".signup-btn").onclick = function () {
    window.location.href = "signup.html";
};
// ==========================
// LIGHT / DARK MODE
// ==========================

const themeToggle = document.getElementById("themeToggle");
const themeIcon = document.getElementById("themeIcon");

// Load saved theme
if(localStorage.getItem("theme") === "dark"){

    document.body.classList.add("dark-mode");

    themeIcon.classList.remove("fa-moon");
    themeIcon.classList.add("fa-sun");

}

themeToggle.addEventListener("click",function(){

    document.body.classList.toggle("dark-mode");

    if(document.body.classList.contains("dark-mode")){

        themeIcon.classList.remove("fa-moon");
        themeIcon.classList.add("fa-sun");

        localStorage.setItem("theme","dark");

    }

    else{

        themeIcon.classList.remove("fa-sun");
        themeIcon.classList.add("fa-moon");

        localStorage.setItem("theme","light");

    }

});